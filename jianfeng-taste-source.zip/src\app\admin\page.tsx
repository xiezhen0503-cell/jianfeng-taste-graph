import Link from "next/link";
import { ArrowLeft, ArrowUpRight, BarChart3, Box, ExternalLink, Plus, Users } from "lucide-react";
import { PRODUCTS } from "@/lib/data";

const metrics = [
  { label: "今日食客", value: "284", change: "+18.4%", note: "较昨日", icon: <Users size={19} /> },
  { label: "测试完成率", value: "72.6%", change: "+6.2%", note: "206 人完成", icon: <BarChart3 size={19} /> },
  { label: "平均 Swipe", value: "11.8", change: "+2.1", note: "每位食客", icon: <ArrowUpRight size={19} /> },
  { label: "购买跳转", value: "39", change: "13.7%", note: "推荐点击率", icon: <ExternalLink size={19} /> },
];

export default function AdminPage() {
  return (
    <main className="admin-page">
      <aside className="admin-sidebar">
        <div className="admin-brand"><i><span /><span /><span /></i><b>尖锋 Taste</b><em>MVP</em></div>
        <nav>
          <a className="is-active"><BarChart3 size={18} />经营看板</a>
          <a><Box size={18} />商品与 Taste DNA</a>
          <a><Users size={18} />食客画像</a>
        </nav>
        <Link href="/"><ArrowLeft size={16} /> 返回用户端原型</Link>
      </aside>
      <section className="admin-content">
        <header className="admin-header">
          <div><span>2026 年 8 月 21 日 · 实时演示数据</span><h1>Taste 经营看板</h1></div>
          <button><Plus size={17} /> 新增商品</button>
        </header>
        <div className="admin-metrics">
          {metrics.map((metric) => <article key={metric.label}>
            <div><span>{metric.icon}</span><em>{metric.label}</em></div>
            <strong>{metric.value}</strong>
            <p><b>{metric.change}</b> {metric.note}</p>
          </article>)}
        </div>
        <div className="admin-grid">
          <article className="admin-panel admin-chart">
            <div className="admin-panel__head"><div><span>核心漏斗</span><h2>从测试到购买跳转</h2></div><em>近 7 日</em></div>
            <div className="funnel-bars">
              {[
                ["开始测试", 284, 100], ["完成 Taste ID", 206, 73], ["查看推荐", 188, 66], ["查看商品", 92, 32], ["购买跳转", 39, 14],
              ].map(([label, value, width]) => <div key={String(label)}><span>{label}</span><i><b style={{ width: `${width}%` }} /></i><strong>{value}</strong></div>)}
            </div>
          </article>
          <article className="admin-panel admin-persona">
            <div className="admin-panel__head"><div><span>热门人格</span><h2>今天谁最多？</h2></div></div>
            <div className="persona-rank"><i>🌶️</i><span><b>无辣不欢派</b><em>占今日完成测试 24%</em></span><strong>49</strong></div>
            <div className="persona-rank"><i>🥩</i><span><b>咸香肉食探索家</b><em>占今日完成测试 19%</em></span><strong>39</strong></div>
            <div className="persona-rank"><i>🥬</i><span><b>清爽本味观察员</b><em>占今日完成测试 14%</em></span><strong>29</strong></div>
          </article>
        </div>
        <article className="admin-panel admin-products">
          <div className="admin-panel__head"><div><span>商品管理</span><h2>热门推荐与 Taste DNA</h2></div><button>查看全部 <ArrowUpRight size={15} /></button></div>
          <div className="admin-table">
            <div className="admin-tr admin-th"><span>商品</span><span>价格</span><span>Top DNA</span><span>曝光 / 点击</span><span>状态</span></div>
            {PRODUCTS.slice(0, 5).map((product, index) => {
              const dna = Object.entries(product.vector).sort((a, b) => b[1] - a[1]).slice(0, 2);
              return <div className="admin-tr" key={product.id}>
                <span className="admin-product-name">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={product.image} alt="" /><b>{product.name}</b>
                </span>
                <span>¥{product.price}</span>
                <span className="dna-tags">{dna.map(([key]) => <i key={key}>{key}</i>)}</span>
                <span>{1860 - index * 173} / {284 - index * 29}</span>
                <span><em className="status-dot" /> 上架中</span>
              </div>;
            })}
          </div>
        </article>
      </section>
    </main>
  );
}
