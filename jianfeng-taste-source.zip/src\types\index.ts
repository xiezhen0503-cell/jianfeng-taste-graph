export type TasteKey =
  | "meat"
  | "spicy"
  | "sweet"
  | "savory"
  | "healthy"
  | "adventurous"
  | "convenience"
  | "value"
  | "stockup"
  | "social";

export type TasteVector = Record<TasteKey, number>;

export type TasteOption = {
  label: string;
  emoji: string;
  caption: string;
  delta: Partial<TasteVector>;
};

export type TasteQuestion = {
  id: number;
  kicker: string;
  question: string;
  options: TasteOption[];
};

export type Product = {
  id: string;
  name: string;
  subtitle: string;
  description: string;
  price: number;
  unit: string;
  priceSource: string;
  image: string;
  badge?: string;
  externalUrl: string;
  vector: TasteVector;
};

export type NavView = "home" | "discover" | "taste" | "profile";
export type AppView = "welcome" | "test" | "result" | NavView;
