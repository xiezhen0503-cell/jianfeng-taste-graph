# 尖锋 Taste Graph MVP

一个可交互的移动端 Web 原型：用户通过 8 道直觉题生成 10 维 Taste ID，随后在推荐首页和 Swipe Feed 中继续训练自己的口味图谱。

## 已实现

- 30 秒 Taste Test 与动态答案反馈
- 10 维 Taste Vector、Taste Persona、雷达图与理解度
- 基于相似度的个性化商品排序和推荐理由
- 可拖拽 Taste Feed；操作通过 EMA 小幅更新用户画像
- 商品 Taste DNA、匹配理由和有赞外链出口
- 8 个真实尖锋商品、D 盘正式主图与已记录渠道参考价
- Taste ID 完成礼：满 69 减 10 元 Taste 券，领取状态可持久化
- 好友口味匹配与共同菜单演示
- `/admin` 经营漏斗、热门人格与商品 Taste DNA 看板
- 匿名状态通过 `localStorage` 保存
- 375 / 390 / 414px 移动端适配、键盘焦点、减少动态效果偏好
- Taste Engine 和 Recommendation Engine 单元测试

## 本地运行

```bash
pnpm install
pnpm dev
```

打开 [http://localhost:3000](http://localhost:3000)。

```bash
pnpm test
pnpm build
```

## 原型架构

- `src/components/taste-app.tsx`：原型页面与交互状态
- `src/lib/taste-engine.ts`：口味计算、画像更新、人格与推荐
- `src/lib/data.ts`：测试题、商品和好友演示数据
- `src/types/index.ts`：统一 TypeScript 类型
- `src/app/globals.css`：移动端视觉系统与动效

本版采用 mock-first 结构，没有连接 Supabase，也不处理账号、支付、订单和物流。商品主图来自 `D:\尖锋食客产品主图知识库`；页面价格采用该知识库中 2026-07-07 记录的短视频挂车价，并明确标注为渠道参考价，真实结算仍以有赞商品页为准。`Taste Engine` 与 UI 分离，后续可将本地状态替换为 Supabase Repository，并保持推荐接口不变。

## Taste Graph 逻辑

初测答案以 delta 叠加至初始向量，并 clamp 到 0–100。商品匹配综合余弦相似度与维度距离；Swipe 行为使用最高 9% 学习率的指数移动平均，避免一次选择大幅改变画像。理解度由已答问题数和 Swipe 数量渐进计算。

## 后续接入

1. Supabase 匿名会话、正式账号与数据合并
2. 完整 20 题题库与 30+ 真实尖锋商品
3. 埋点、管理后台与实验分组
4. 真实 Taste 分享链接及图片导出
5. 有赞商品、购买与复购事件回流
