import type { Product, TasteKey, TasteVector } from "@/types";

export const TASTE_KEYS: TasteKey[] = [
  "meat",
  "spicy",
  "sweet",
  "savory",
  "healthy",
  "adventurous",
  "convenience",
  "value",
  "stockup",
  "social",
];

export const TASTE_LABELS: Record<TasteKey, string> = {
  meat: "肉食",
  spicy: "辣味",
  sweet: "甜口",
  savory: "咸香",
  healthy: "轻盈",
  adventurous: "尝鲜",
  convenience: "方便",
  value: "划算",
  stockup: "囤货",
  social: "分享",
};

export const INITIAL_TASTE: TasteVector = {
  meat: 45,
  spicy: 45,
  sweet: 45,
  savory: 45,
  healthy: 45,
  adventurous: 45,
  convenience: 45,
  value: 45,
  stockup: 45,
  social: 45,
};

export const clamp = (value: number) => Math.max(0, Math.min(100, Math.round(value)));

export type TasteTestScore = {
  vector: TasteVector;
  confidence: number;
  coverage: number;
  consistency: number;
};

/**
 * Evidence-normalized scoring. A dimension only becomes extreme when it receives
 * repeated, consistent evidence; contradictory answers naturally pull it back
 * toward 50 instead of producing an arbitrary accumulated score.
 */
export function scoreTasteTest(deltas: Partial<TasteVector>[]): TasteTestScore {
  const net = Object.fromEntries(TASTE_KEYS.map((key) => [key, 0])) as TasteVector;
  const evidence = Object.fromEntries(TASTE_KEYS.map((key) => [key, 0])) as TasteVector;
  const directions = Object.fromEntries(TASTE_KEYS.map((key) => [key, [] as number[]])) as Record<TasteKey, number[]>;

  for (const delta of deltas) {
    for (const key of TASTE_KEYS) {
      const value = delta[key] ?? 0;
      net[key] += value;
      evidence[key] += Math.abs(value);
      if (Math.abs(value) >= 5) directions[key].push(Math.sign(value));
    }
  }

  const vector = Object.fromEntries(TASTE_KEYS.map((key) => {
    const normalized = net[key] / Math.max(18, evidence[key] + 12);
    return [key, clamp(50 + normalized * 48)];
  })) as TasteVector;

  const measured = TASTE_KEYS.filter((key) => evidence[key] >= 16);
  const coverage = Math.round(measured.length / TASTE_KEYS.length * 100);
  const repeatable = TASTE_KEYS.filter((key) => directions[key].length >= 2);
  const consistency = repeatable.length
    ? Math.round(repeatable.reduce((sum, key) => {
        const direction = directions[key];
        const agreement = Math.abs(direction.reduce((total, value) => total + value, 0)) / direction.length;
        return sum + agreement;
      }, 0) / repeatable.length * 100)
    : 70;
  const completion = Math.min(1, deltas.length / 12);
  const confidence = clamp(18 + completion * 47 + coverage * 0.2 + consistency * 0.15);
  return { vector, confidence, coverage, consistency };
}

export function applyTasteTestAnswers(deltas: Partial<TasteVector>[]): TasteVector {
  return scoreTasteTest(deltas).vector;
}

export function calculateTasteSimilarity(a: TasteVector, b: TasteVector): number {
  const centeredA = Object.fromEntries(TASTE_KEYS.map((key) => [key, a[key] - 50])) as TasteVector;
  const centeredB = Object.fromEntries(TASTE_KEYS.map((key) => [key, b[key] - 50])) as TasteVector;
  const dot = TASTE_KEYS.reduce((sum, key) => sum + centeredA[key] * centeredB[key], 0);
  const normA = Math.sqrt(TASTE_KEYS.reduce((sum, key) => sum + centeredA[key] ** 2, 0));
  const normB = Math.sqrt(TASTE_KEYS.reduce((sum, key) => sum + centeredB[key] ** 2, 0));
  const distance = Math.sqrt(
    TASTE_KEYS.reduce((sum, key) => sum + (a[key] - b[key]) ** 2, 0) / TASTE_KEYS.length,
  );
  const proximity = Math.max(0, 100 - distance * 1.45);
  if (!normA || !normB) return clamp(proximity);
  const direction = ((dot / (normA * normB)) + 1) * 50;
  return clamp(direction * 0.62 + proximity * 0.38);
}

export function calculateTasteCompatibility(a: TasteVector, b: TasteVector): number {
  return calculateTasteSimilarity(a, b);
}

export function updateTasteFromAction(
  current: TasteVector,
  product: TasteVector,
  weight: number,
): TasteVector {
  const alpha = Math.min(0.09, Math.abs(weight) * 0.018);
  return Object.fromEntries(
    TASTE_KEYS.map((key) => {
      const target = weight >= 0 ? product[key] : 100 - product[key];
      return [key, clamp(current[key] + alpha * (target - current[key]))];
    }),
  ) as TasteVector;
}

export function generateTastePersona(vector: TasteVector) {
  if (vector.spicy >= 78) return { name: "无辣不欢派", emoji: "🌶️", note: "你追的是热烈，不是刺激。香、辣、脆一到位，筷子就停不下来。" };
  if (vector.sweet >= 76) return { name: "甜品快乐星人", emoji: "🍰", note: "你很会给日常加一点甜。奶香、绵密和刚好的糖，是你的情绪开关。" };
  if (vector.healthy >= 75) return { name: "清爽本味观察员", emoji: "🥬", note: "你不吃寡淡，只喜欢食材本身够好。清爽、均衡，也得有滋有味。" };
  if (vector.value >= 72 && vector.stockup >= 68) return { name: "聪明囤货掌柜", emoji: "🧺", note: "你买得认真，也吃得明白。好吃是底线，耐放和划算同样重要。" };
  if (vector.adventurous >= 77) return { name: "新品雷达猎手", emoji: "🛰️", note: "别人收藏攻略，你收藏新口味。菜单上越陌生的名字，越容易被你点中。" };
  if (vector.social >= 78) return { name: "聚餐气氛担当", emoji: "🥂", note: "食物对你不只是一顿饭，更是把人聚在一起的理由。" };
  if (vector.convenience >= 76 && vector.savory >= 60) return { name: "深夜速食玩家", emoji: "🍜", note: "你要的是快，但从不愿意将就。十分钟内，也能吃出一顿像样的夜宵。" };
  if (vector.meat >= 72 && vector.savory >= 65) return { name: "咸香肉食探索家", emoji: "🥩", note: "炙烤焦边、丰润肉汁、咸香回味——这是你最熟悉的快乐路径。" };
  if (vector.sweet > vector.savory) return { name: "柔软口感收藏家", emoji: "🥐", note: "你偏爱温柔、细腻、带一点奶香的食物，吃东西也讲究情绪氛围。" };
  if (vector.adventurous < 42) return { name: "经典味道守门员", emoji: "🍚", note: "你相信经得起时间的味道。熟悉不等于无聊，稳定好吃才是真本事。" };
  if (vector.convenience >= 65) return { name: "效率美味主义者", emoji: "⏱️", note: "你的时间很贵，但胃口不能敷衍。方便与好吃，你坚持两个都要。" };
  return { name: "平衡味觉策展人", emoji: "🍽️", note: "浓淡、荤素、新旧，你总能找到舒服的中间点，也最擅长替大家点菜。" };
}

export function calculateTasteConfidence(answerCount: number, swipeCount: number, testConfidence?: number): number {
  const testBase = testConfidence ?? Math.min(82, 18 + answerCount * 5.3);
  const behavioralLift = Math.min(15, Math.log2(swipeCount + 1) * 3.8);
  return clamp(Math.min(97, testBase + behavioralLift));
}

export function recommendProducts(products: Product[], vector: TasteVector) {
  return products
    .map((product, index) => {
      const tasteMatch = calculateTasteSimilarity(vector, product.vector);
      const score = tasteMatch * 0.88 + (92 - index * 2) * 0.07 + (84 + (index % 3) * 4) * 0.05;
      const reasons = TASTE_KEYS
        .map((key) => ({
          key,
          affinity: (100 - Math.abs(vector[key] - product.vector[key]))
            * (0.65 * Math.abs(vector[key] - 50) + 0.35 * Math.abs(product.vector[key] - 50)),
        }))
        .sort((a, b) => b.affinity - a.affinity)
        .slice(0, 3)
        .map(({ key }) => TASTE_LABELS[key]);
      return { product, tasteMatch, score, reasons };
    })
    .sort((a, b) => b.score - a.score);
}
