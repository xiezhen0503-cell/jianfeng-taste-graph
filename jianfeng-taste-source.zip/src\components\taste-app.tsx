"use client";

import {
  ArrowLeft,
  ArrowRight,
  Bookmark,
  Check,
  ChevronRight,
  CircleUserRound,
  Compass,
  Copy,
  Download,
  Heart,
  Home,
  Info,
  RotateCcw,
  Settings,
  Share2,
  ShoppingBag,
  Sparkles,
  TicketPercent,
  ThumbsDown,
  Utensils,
  X,
  Zap,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { DEMO_FRIEND_VECTOR, PRODUCTS, QUESTIONS } from "@/lib/data";
import {
  INITIAL_TASTE,
  TASTE_KEYS,
  TASTE_LABELS,
  applyTasteTestAnswers,
  calculateTasteCompatibility,
  calculateTasteConfidence,
  generateTastePersona,
  recommendProducts,
  scoreTasteTest,
  updateTasteFromAction,
} from "@/lib/taste-engine";
import type { AppView, NavView, Product, TasteKey, TasteVector } from "@/types";

const STORAGE_KEY = "jianfeng-taste-prototype";

type StoredTaste = {
  vector: TasteVector;
  answerCount: number;
  swipeCount: number;
  testConfidence?: number;
  couponClaimed?: boolean;
};

const DEFAULT_STORED: StoredTaste = { vector: INITIAL_TASTE, answerCount: 0, swipeCount: 0, couponClaimed: false };

function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <div className={`brand ${compact ? "brand--compact" : ""}`} aria-label="尖锋 Taste">
      <span className="brand__mark"><span /><span /><span /></span>
      <span>尖锋 <b>Taste</b></span>
    </div>
  );
}

function TasteOrbit({ vector = INITIAL_TASTE, small = false }: { vector?: TasteVector; small?: boolean }) {
  const dots: { key: TasteKey; label: string; emoji: string; angle: number }[] = [
    { key: "spicy", label: "辣", emoji: "🌶", angle: -78 },
    { key: "sweet", label: "甜", emoji: "🍰", angle: -20 },
    { key: "savory", label: "鲜", emoji: "🍜", angle: 38 },
    { key: "healthy", label: "轻", emoji: "🥬", angle: 92 },
    { key: "meat", label: "肉", emoji: "🥩", angle: 152 },
    { key: "adventurous", label: "新", emoji: "✨", angle: 210 },
  ];
  return (
    <div className={`taste-orbit ${small ? "taste-orbit--small" : ""}`} aria-hidden="true">
      <div className="taste-orbit__ring taste-orbit__ring--outer" />
      <div className="taste-orbit__ring taste-orbit__ring--inner" />
      <div className="taste-orbit__core"><span>你的</span><strong>味觉</strong></div>
      {dots.map((dot) => {
        const radius = (small ? 94 : 132) * (0.74 + vector[dot.key] / 380);
        const x = Math.cos((dot.angle * Math.PI) / 180) * radius;
        const y = Math.sin((dot.angle * Math.PI) / 180) * radius;
        return (
          <div className="taste-orbit__dot" key={dot.key} style={{ transform: `translate(${x}px, ${y}px)` }}>
            <span>{dot.emoji}</span><small>{dot.label}</small>
          </div>
        );
      })}
    </div>
  );
}

function RadarChart({ vector, compact = false }: { vector: TasteVector; compact?: boolean }) {
  const keys = TASTE_KEYS.slice(0, 8);
  const size = compact ? 220 : 278;
  const center = size / 2;
  const radius = compact ? 74 : 92;
  const pointAt = (value: number, index: number, maxRadius = radius) => {
    const angle = -Math.PI / 2 + (index * Math.PI * 2) / keys.length;
    const r = maxRadius * (value / 100);
    return [center + Math.cos(angle) * r, center + Math.sin(angle) * r];
  };
  const polygon = keys.map((key, index) => pointAt(vector[key], index).join(",")).join(" ");
  return (
    <svg className="radar" viewBox={`0 0 ${size} ${size}`} role="img" aria-label="Taste 口味雷达图">
      {[0.33, 0.66, 1].map((level) => (
        <polygon key={level} points={keys.map((_, i) => pointAt(100, i, radius * level).join(",")).join(" ")} className="radar__grid" />
      ))}
      {keys.map((_, index) => {
        const [x, y] = pointAt(100, index);
        return <line key={index} x1={center} y1={center} x2={x} y2={y} className="radar__line" />;
      })}
      <polygon points={polygon} className="radar__shape" />
      {keys.map((key, index) => {
        const [x, y] = pointAt(100, index, radius + (compact ? 25 : 34));
        return <text key={key} x={x} y={y} className="radar__label">{TASTE_LABELS[key]}</text>;
      })}
    </svg>
  );
}

function MatchRing({ value, size = 68 }: { value: number; size?: number }) {
  return (
    <div className="match-ring" style={{ "--match": `${value * 3.6}deg`, "--ring-size": `${size}px` } as React.CSSProperties}>
      <div><strong>{value}</strong><span>%</span></div>
    </div>
  );
}

function TopBar({ onBack, action }: { onBack?: () => void; action?: React.ReactNode }) {
  return (
    <header className="topbar">
      {onBack ? <button className="icon-button" onClick={onBack} aria-label="返回"><ArrowLeft size={20} /></button> : <Logo compact />}
      <div className="topbar__spacer" />
      {action}
    </header>
  );
}

function BottomNav({ active, onChange }: { active: NavView; onChange: (view: NavView) => void }) {
  const items: { id: NavView; label: string; icon: React.ReactNode }[] = [
    { id: "home", label: "首页", icon: <Home size={21} /> },
    { id: "discover", label: "发现", icon: <Compass size={22} /> },
    { id: "taste", label: "Taste", icon: <Sparkles size={21} /> },
    { id: "profile", label: "我的", icon: <CircleUserRound size={21} /> },
  ];
  return (
    <nav className="bottom-nav" aria-label="主导航">
      {items.map((item) => (
        <button key={item.id} className={active === item.id ? "is-active" : ""} onClick={() => onChange(item.id)}>
          <span>{item.icon}</span><small>{item.label}</small>
        </button>
      ))}
    </nav>
  );
}

function ProductMiniCard({ product, match, reasons, onClick }: { product: Product; match: number; reasons: string[]; onClick: () => void }) {
  return (
    <button className="product-mini" onClick={onClick}>
      <div className="product-mini__image">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={product.image} alt={product.name} />
        <span>{match}% MATCH</span>
      </div>
      <div className="product-mini__copy">
        <strong>{product.name}</strong>
        <p>{reasons.join(" · ")}</p>
        <div><b>¥{product.price}</b><ChevronRight size={17} /></div>
      </div>
    </button>
  );
}

function WelcomeView({ onStart, onExplain }: { onStart: () => void; onExplain: () => void }) {
  return (
    <main className="view welcome-view">
      <TopBar action={<button className="text-button" onClick={onExplain}>它怎么懂我？</button>} />
      <section className="welcome-hero">
        <div className="welcome-hero__copy">
          <span className="eyebrow">你的口味，不该只有“喜欢吃”</span>
          <h1>45 秒，找到你的<br /><em>味觉人格</em></h1>
          <p>告诉尖锋你会夹哪一筷子。之后每一次选择，都让推荐更像你。</p>
        </div>
        <TasteOrbit />
      </section>
      <section className="welcome-actions">
        <button className="primary-button" onClick={onStart}>开始测我的 Taste ID <ArrowRight size={20} /></button>
        <div className="welcome-proof">
          <span><Check size={14} /> 约 45 秒</span>
          <span><Check size={14} /> 无需登录</span>
          <span><Check size={14} /> 12 道情境题</span>
        </div>
        <p><b>12,684</b> 位食客已经找到自己的味觉同类</p>
      </section>
    </main>
  );
}

function MethodSheet({ onClose }: { onClose: () => void }) {
  return (
    <div className="sheet-backdrop" onClick={onClose}>
      <article className="method-sheet" onClick={(event) => event.stopPropagation()}>
        <button className="sheet-close" onClick={onClose} aria-label="关闭"><X size={20} /></button>
        <span className="eyebrow">WHY IT GETS YOU</span>
        <h2>不是贴标签，<br />是在收集味觉证据。</h2>
        <p>12 道题覆盖 10 个维度。同一偏好会换场景再问一次，避免一次冲动决定整个结果。</p>
        <div className="method-steps">
          <div><i>01</i><span><strong>双场景交叉验证</strong><small>想吃什么 + 真正怎么买，减少“嘴上喜欢”。</small></span></div>
          <div><i>02</i><span><strong>矛盾自动回归中性</strong><small>两次选择不一致时，不武断地把你归到极端。</small></span></div>
          <div><i>03</i><span><strong>越用越懂，而非越用越窄</strong><small>Swipe 只做小步校准，并保留尝鲜空间。</small></span></div>
        </div>
        <div className="method-proof"><span>10</span> 维 Taste Graph <em>·</em> <span>12</span> 道情境题 <em>·</em> <span>2×</span> 交叉验证</div>
        <button className="primary-button" onClick={onClose}>明白了，开始测试 <ArrowRight size={18} /></button>
      </article>
    </div>
  );
}

function TasteTestView({ questionIndex, selected, vector, onSelect, onBack }: {
  questionIndex: number;
  selected: number | null;
  vector: TasteVector;
  onSelect: (option: number) => void;
  onBack: () => void;
}) {
  const question = QUESTIONS[questionIndex];
  return (
    <main className="view test-view">
      <TopBar onBack={onBack} action={<span className="step-count"><b>{questionIndex + 1}</b> / {QUESTIONS.length}</span>} />
      <div className="progress-track"><span style={{ width: `${((questionIndex + 1) / QUESTIONS.length) * 100}%` }} /></div>
      <section className="question-head">
        <span className="eyebrow">{question.kicker}</span>
        <h2>{question.question}</h2>
        <p>跟着第一反应选，没有标准答案。</p>
      </section>
      <section className="option-stack">
        {question.options.map((option, index) => (
          <button
            key={option.label}
            className={`taste-option ${selected === index ? "is-selected" : ""}`}
            onClick={() => onSelect(index)}
          >
            <span className="taste-option__emoji">{option.emoji}</span>
            <span className="taste-option__copy"><strong>{option.label}</strong><small>{option.caption}</small></span>
            <span className="taste-option__check"><Check size={18} /></span>
          </button>
        ))}
      </section>
      <div className="test-live">
        <TasteOrbit vector={vector} small />
        <div><span>尖锋正在认识你</span><strong>{questionIndex < 2 ? "轮廓刚刚出现" : questionIndex < 6 ? "偏好越来越清楚" : "Taste ID 即将生成"}</strong></div>
      </div>
    </main>
  );
}

function ResultView({ vector, confidence, onContinue, onShare }: { vector: TasteVector; confidence: number; onContinue: () => void; onShare: () => void }) {
  const persona = generateTastePersona(vector);
  const topKeys = [...TASTE_KEYS].sort((a, b) => vector[b] - vector[a]).slice(0, 3);
  return (
    <main className="view result-view">
      <TopBar action={<button className="icon-button" onClick={onShare} aria-label="分享"><Share2 size={20} /></button>} />
      <section className="result-intro">
        <span className="eyebrow">TASTE ID · 已生成</span>
        <div className="persona-emoji">{persona.emoji}</div>
        <h1>{persona.name}</h1>
        <p>{persona.note}</p>
      </section>
      <section className="taste-card">
        <div className="taste-card__stamp">JF / {String(Math.round(vector.meat * 73 + vector.savory * 19)).slice(0, 4)}</div>
        <RadarChart vector={vector} compact />
        <div className="taste-card__top">
          {topKeys.map((key) => <div key={key}><span>{TASTE_LABELS[key]}</span><strong>{vector[key]}</strong></div>)}
        </div>
        <div className="taste-card__rare"><Sparkles size={15} /> 只有 <b>8.7%</b> 的食客和你一样</div>
      </section>
      <section className="result-actions">
        <button className="primary-button" onClick={onContinue}>看看有多懂我 <ArrowRight size={20} /></button>
        <button className="secondary-button" onClick={onShare}><Share2 size={18} /> 生成我的 Taste Card</button>
        <div className="confidence-note"><span>初始理解度 {confidence}%</span><div><i style={{ width: `${confidence}%` }} /></div></div>
      </section>
    </main>
  );
}

function HomeView({ vector, confidence, recommendations, onProduct, onDiscover, onTaste, couponClaimed }: {
  vector: TasteVector;
  confidence: number;
  recommendations: ReturnType<typeof recommendProducts>;
  onProduct: (p: Product) => void;
  onDiscover: () => void;
  onTaste: () => void;
  couponClaimed?: boolean;
}) {
  const persona = generateTastePersona(vector);
  const first = recommendations[0];
  return (
    <main className="view app-view home-view">
      <TopBar action={<button className="avatar-button" aria-label="个人资料">J</button>} />
      <section className="home-greeting">
        <span>下午好，John</span>
        <h1>今天想吃点<br />什么感觉？</h1>
      </section>
      <button className="identity-strip" onClick={onTaste}>
        <span className="identity-strip__emoji">{persona.emoji}</span>
        <span><small>YOUR TASTE</small><strong>{persona.name}</strong><em>理解度 {confidence}%</em></span>
        <ChevronRight size={20} />
      </button>
      {couponClaimed && <div className="coupon-wallet"><TicketPercent size={18} /><span><strong>¥10 Taste 券已到账</strong><small>满 69 元可用 · 领券后 7 天内有效</small></span><b>已领取</b></div>}
      {first && (
        <section className="hero-rec" onClick={() => onProduct(first.product)} role="button" tabIndex={0}>
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={first.product.image} alt={first.product.name} />
          <div className="hero-rec__veil" />
          <div className="hero-rec__match"><Zap size={15} fill="currentColor" /> {first.tasteMatch}% MATCH</div>
          {first.product.badge && <div className="hero-rec__badge">{first.product.badge}</div>}
          <div className="hero-rec__copy">
            <span>今天最懂你的 1 号选手</span>
            <h2>{first.product.name}</h2>
            <p>因为你喜欢：{first.reasons.join(" · ")}</p>
            <div><b>¥{first.product.price}</b><button>看懂你的理由 <ArrowRight size={16} /></button></div>
          </div>
        </section>
      )}
      <section className="section-heading">
        <div><span>FOR YOU</span><h2>再给你 4 个准答案</h2></div>
        <button onClick={onDiscover}>继续刷 <ArrowRight size={15} /></button>
      </section>
      <div className="product-row">
        {recommendations.slice(1, 5).map((item) => (
          <ProductMiniCard key={item.product.id} product={item.product} match={item.tasteMatch} reasons={item.reasons} onClick={() => onProduct(item.product)} />
        ))}
      </div>
      <section className="learn-more-card">
        <div><Sparkles size={20} /><span><strong>再刷 5 个，推荐会更准</strong><small>每一次想吃 / 不想吃，都在更新你的 Taste Graph。</small></span></div>
        <button onClick={onDiscover}>现在去刷</button>
      </section>
    </main>
  );
}

function DiscoverView({ item, index, total, dragX, onDragStart, onDragMove, onDragEnd, onAction, onProduct }: {
  item: ReturnType<typeof recommendProducts>[number];
  index: number;
  total: number;
  dragX: number;
  onDragStart: (e: React.PointerEvent) => void;
  onDragMove: (e: React.PointerEvent) => void;
  onDragEnd: (e: React.PointerEvent) => void;
  onAction: (weight: number) => void;
  onProduct: (p: Product) => void;
}) {
  const rotation = dragX / 24;
  return (
    <main className="view app-view discover-view">
      <TopBar action={<span className="step-count"><b>{index + 1}</b> / {total}</span>} />
      <section className="discover-heading">
        <div><span className="eyebrow">TASTE FEED</span><h1>这一口，想不想？</h1></div>
        <button className="icon-button" aria-label="重置"><RotateCcw size={18} /></button>
      </section>
      <section className="swipe-stage">
        <div className="swipe-card swipe-card--behind" />
        <article
          className="swipe-card"
          style={{ transform: `translateX(${dragX}px) rotate(${rotation}deg)` }}
          onPointerDown={onDragStart}
          onPointerMove={onDragMove}
          onPointerUp={onDragEnd}
          onPointerCancel={onDragEnd}
        >
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={item.product.image} alt={item.product.name} draggable={false} />
          <div className="swipe-card__shade" />
          {dragX > 35 && <div className="swipe-stamp swipe-stamp--yes">想吃</div>}
          {dragX < -35 && <div className="swipe-stamp swipe-stamp--no">略过</div>}
          <div className="swipe-card__copy">
            <span><Zap size={14} fill="currentColor" /> {item.tasteMatch}% MATCH</span>
            <h2>{item.product.name}</h2>
            <p>{item.product.subtitle}</p>
            <div>{item.reasons.map((reason) => <i key={reason}>{reason}</i>)}</div>
            <button onPointerDown={(e) => e.stopPropagation()} onClick={() => onProduct(item.product)}>看看为什么懂我 <ChevronRight size={16} /></button>
          </div>
        </article>
      </section>
      <section className="swipe-actions">
        <button className="swipe-action swipe-action--no" onClick={() => onAction(-1)}><ThumbsDown size={23} /><span>不太喜欢</span></button>
        <button className="swipe-action swipe-action--super" onClick={() => onAction(2)}><Sparkles size={26} fill="currentColor" /><span>超想吃</span></button>
        <button className="swipe-action swipe-action--yes" onClick={() => onAction(1)}><Heart size={25} fill="currentColor" /><span>想吃</span></button>
      </section>
      <p className="swipe-hint"><ArrowLeft size={14} /> 也可以直接左右滑 <ArrowRight size={14} /></p>
    </main>
  );
}

function TasteProfileView({ vector, confidence, swipeCount, onShare, onFriend, onRetest }: {
  vector: TasteVector;
  confidence: number;
  swipeCount: number;
  onShare: () => void;
  onFriend: () => void;
  onRetest: () => void;
}) {
  const persona = generateTastePersona(vector);
  return (
    <main className="view app-view taste-profile-view">
      <TopBar action={<button className="icon-button" onClick={onShare} aria-label="分享"><Share2 size={20} /></button>} />
      <section className="profile-title">
        <span className="eyebrow">MY TASTE ID</span>
        <h1>{persona.emoji} {persona.name}</h1>
        <p>{persona.note}</p>
      </section>
      <button className="retest-prompt" onClick={onRetest}><RotateCcw size={17} /><span><strong>口味变了？重新测一次</strong><small>用新的答案更新 Taste ID</small></span><ChevronRight size={18} /></button>
      <section className="graph-card">
        <div className="graph-card__head"><span>味觉图谱</span><em>已更新 {swipeCount} 次</em></div>
        <RadarChart vector={vector} />
        <div className="graph-card__confidence">
          <div><span>尖锋对你的理解度</span><b>{confidence}%</b></div>
          <div className="meter"><i style={{ width: `${confidence}%` }} /></div>
          <p>{confidence < 55 ? "再刷几口，你的味觉轮廓会更清楚。" : "已经很懂你，再来几次购买会更准确。"}</p>
        </div>
      </section>
      <section className="taste-bars">
        <div className="section-heading"><div><span>TASTE DNA</span><h2>你的十种味觉信号</h2></div></div>
        {TASTE_KEYS.map((key) => (
          <div className="taste-bar" key={key}>
            <span>{TASTE_LABELS[key]}</span><div><i style={{ width: `${vector[key]}%` }} /></div><b>{vector[key]}</b>
          </div>
        ))}
      </section>
      <button className="friend-card" onClick={onFriend}>
        <span className="friend-card__faces"><i>J</i><i>?</i></span>
        <span><small>TASTE MATCH</small><strong>测测我们能不能吃到一起</strong><em>邀请好友，生成共同口味与菜单</em></span>
        <ChevronRight size={20} />
      </button>
    </main>
  );
}

function ProfileView({ swipeCount, onReset, onFeedback }: { swipeCount: number; onReset: () => void; onFeedback: (message: string) => void }) {
  return (
    <main className="view app-view profile-view">
      <TopBar action={<button className="icon-button" aria-label="设置"><Settings size={20} /></button>} />
      <section className="user-card">
        <div className="user-avatar">J</div>
        <div><span>匿名食客 · 0821</span><h1>John 的味觉档案</h1><p>数据只保存在这台设备</p></div>
      </section>
      <section className="stats-row">
        <div><strong>{swipeCount}</strong><span>刷过的味道</span></div>
        <div><strong>4</strong><span>想吃清单</span></div>
        <div><strong>1</strong><span>好友匹配</span></div>
      </section>
      <section className="settings-list">
        <button onClick={() => onFeedback("想吃清单已同步：当前收藏 4 件商品")}><span><Bookmark size={19} /> 我的想吃清单</span><ChevronRight size={18} /></button>
        <button onClick={() => onFeedback("最近看过：藤椒无骨凤爪、厚汁米线")}><span><ShoppingBag size={19} /> 最近看过</span><ChevronRight size={18} /></button>
        <button onClick={() => onFeedback("可在 Taste 页面生成和保存分享卡")}><span><Share2 size={19} /> 我的 Taste 分享</span><ChevronRight size={18} /></button>
        <button onClick={() => onFeedback("每次选择都会轻微更新十维 Taste Graph")}><span><Info size={19} /> Taste 如何工作</span><ChevronRight size={18} /></button>
      </section>
      <button className="reset-button" onClick={onReset}><RotateCcw size={17} /> 重新测试 Taste ID</button>
      <p className="prototype-note">尖锋 Taste · 可交互 MVP 原型 v0.1</p>
    </main>
  );
}

function ProductSheet({ product, vector, couponClaimed, onClose, onBuy }: { product: Product; vector: TasteVector; couponClaimed?: boolean; onClose: () => void; onBuy: () => void }) {
  const recommendation = recommendProducts([product], vector)[0];
  const topDna = TASTE_KEYS.map((key) => ({ key, value: product.vector[key] })).sort((a, b) => b.value - a.value).slice(0, 4);
  return (
    <div className="sheet-backdrop" onClick={onClose}>
      <article className="product-sheet" onClick={(e) => e.stopPropagation()}>
        <button className="sheet-close" onClick={onClose} aria-label="关闭"><X size={20} /></button>
        <div className="product-sheet__image">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src={product.image} alt={product.name} />
          <div className="product-sheet__ring"><MatchRing value={recommendation.tasteMatch} /></div>
        </div>
        <div className="product-sheet__body">
          <span className="eyebrow">{product.badge ?? "尖锋为你找到"}</span>
          <h2>{product.name}</h2>
          <p>{product.description}</p>
          <div className="price-row"><strong>¥{product.price}</strong><span>{product.unit}</span></div>
          <div className="price-source">渠道参考价 · {product.priceSource}</div>
          {couponClaimed && <div className="product-coupon"><TicketPercent size={16} /><span><b>下单可用 ¥10 Taste 券</b><small>满 69 元可用，以商品页实际结算为准</small></span></div>}
          <div className="why-box">
            <span>为什么适合你</span>
            <div>{recommendation.reasons.map((reason) => <i key={reason}><Check size={13} /> {reason}偏好相合</i>)}</div>
          </div>
          <div className="dna-mini">
            <span>商品 Taste DNA</span>
            {topDna.map(({ key, value }) => <div key={key}><small>{TASTE_LABELS[key]}</small><b><i style={{ width: `${value}%` }} /></b><em>{value}</em></div>)}
          </div>
          <button className="primary-button" onClick={onBuy}>{couponClaimed ? "带券去尖锋购买" : "去尖锋购买"} <ShoppingBag size={19} /></button>
          <small className="external-note">将打开尖锋有赞商品页，本原型不处理支付</small>
        </div>
      </article>
    </div>
  );
}

function CouponSheet({ onClaim, onSkip }: { onClaim: () => void; onSkip: () => void }) {
  return (
    <div className="sheet-backdrop coupon-backdrop">
      <article className="coupon-sheet">
        <span className="eyebrow">TASTE TEST · 完成礼</span>
        <div className="coupon-confetti" aria-hidden="true"><i>●</i><i>✦</i><i>●</i><i>✦</i></div>
        <div className="coupon-ticket">
          <div className="coupon-ticket__value"><small>¥</small><strong>10</strong></div>
          <div className="coupon-ticket__copy"><span>尖锋 Taste 券</span><b>满 69 元可用</b><small>领取后 7 天内有效</small></div>
          <em>TASTE<br />GIFT</em>
        </div>
        <h2>口味找到了，<br />第一口也替你省下了。</h2>
        <p>这是完成 Taste ID 的专属礼。领取后会放进“我的”，看中匹配商品时再用。</p>
        <button className="primary-button" onClick={onClaim}>领取 ¥10 Taste 券 <TicketPercent size={19} /></button>
        <button className="coupon-skip" onClick={onSkip}>先看看我的推荐</button>
        <small className="coupon-rule">原型优惠权益 · 每位食客限领 1 张 · 部分活动不可叠加</small>
      </article>
    </div>
  );
}

function RetestSheet({ couponClaimed, onConfirm, onClose }: { couponClaimed?: boolean; onConfirm: () => void; onClose: () => void }) {
  return (
    <div className="sheet-backdrop" onClick={onClose}>
      <article className="retest-sheet" onClick={(event) => event.stopPropagation()}>
        <button className="sheet-close" onClick={onClose} aria-label="关闭"><X size={20} /></button>
        <div className="retest-sheet__icon"><RotateCcw size={25} /></div>
        <span className="eyebrow">UPDATE MY TASTE</span>
        <h2>重新认识一次<br />现在的你？</h2>
        <p>重新完成 12 道情境题后，新的 Taste ID 会替换当前结果，推荐也会随之更新。</p>
        <div className="retest-impact">
          <span><i><Check size={13} /></i> 测试完成前不会覆盖当前结果</span>
          <span><i><Check size={13} /></i> 完成后生成全新的口味图谱</span>
          {couponClaimed && <span><i><Check size={13} /></i> 已领取的 ¥10 Taste 券不会丢失</span>}
        </div>
        <button className="primary-button" onClick={onConfirm}>重新开始 12 道测试 <ArrowRight size={18} /></button>
        <button className="retest-cancel" onClick={onClose}>保留现在的 Taste ID</button>
      </article>
    </div>
  );
}

function ShareCardSheet({ vector, onClose, onCopy, onSave }: { vector: TasteVector; onClose: () => void; onCopy: () => void; onSave: () => void }) {
  const persona = generateTastePersona(vector);
  const topKeys = [...TASTE_KEYS].sort((a, b) => vector[b] - vector[a]).slice(0, 3);
  return (
    <div className="sheet-backdrop share-backdrop" onClick={onClose}>
      <article className="share-sheet" onClick={(event) => event.stopPropagation()}>
        <button className="sheet-close" onClick={onClose} aria-label="关闭"><X size={20} /></button>
        <div className="share-sheet__head"><span className="eyebrow">MY TASTE CARD</span><small>可保存 · 可分享 · 可匹配</small></div>
        <section className="share-poster">
          <div className="share-poster__brand"><Logo compact /><span>JF / 0821</span></div>
          <div className="share-poster__persona"><span>{persona.emoji}</span><small>我的 Taste ID</small><h2>{persona.name}</h2><p>{persona.note}</p></div>
          <RadarChart vector={vector} compact />
          <div className="share-poster__signals">{topKeys.map((key) => <div key={key}><span>{TASTE_LABELS[key]}</span><strong>{vector[key]}</strong></div>)}</div>
          <div className="share-poster__foot"><span><Sparkles size={14} /> 只有 8.7% 的食客和我一样</span><i aria-hidden="true">▦</i></div>
        </section>
        <div className="share-actions">
          <button className="primary-button" onClick={onSave}><Download size={18} /> 保存 Taste Card</button>
          <button className="secondary-button" onClick={onCopy}><Copy size={17} /> 复制邀请链接</button>
        </div>
        <p>把卡片发给朋友，测测你们能不能吃到一起。</p>
      </article>
    </div>
  );
}

function saveTasteCardPng(vector: TasteVector) {
  const persona = generateTastePersona(vector);
  const topKeys = [...TASTE_KEYS].sort((a, b) => vector[b] - vector[a]).slice(0, 5);
  const canvas = document.createElement("canvas");
  canvas.width = 1080;
  canvas.height = 1440;
  const context = canvas.getContext("2d");
  if (!context) return;
  context.fillStyle = "#1e2923";
  context.fillRect(0, 0, canvas.width, canvas.height);
  context.fillStyle = "#b7d94b";
  context.beginPath();
  context.arc(930, 110, 180, 0, Math.PI * 2);
  context.fill();
  context.fillStyle = "#f25f32";
  context.beginPath();
  context.arc(70, 1330, 210, 0, Math.PI * 2);
  context.fill();
  context.fillStyle = "#fffdf8";
  context.font = "700 34px 'Microsoft YaHei', sans-serif";
  context.fillText("尖锋 Taste", 80, 95);
  context.fillStyle = "#f25f32";
  context.font = "800 24px Arial, sans-serif";
  context.fillText("MY TASTE ID", 80, 190);
  context.fillStyle = "#fffdf8";
  context.font = "800 68px 'Microsoft YaHei', sans-serif";
  context.fillText(persona.name, 80, 280);
  context.fillStyle = "#bfc6c0";
  context.font = "400 26px 'Microsoft YaHei', sans-serif";
  const note = persona.note.length > 28 ? `${persona.note.slice(0, 28)}…` : persona.note;
  context.fillText(note, 80, 335);
  context.fillStyle = "#fffdf8";
  context.beginPath();
  context.roundRect(80, 405, 920, 730, 46);
  context.fill();
  context.fillStyle = "#1e2923";
  context.font = "800 28px 'Microsoft YaHei', sans-serif";
  context.fillText("我的味觉信号", 135, 480);
  topKeys.forEach((key, index) => {
    const y = 575 + index * 108;
    context.fillStyle = "#6e756f";
    context.font = "600 25px 'Microsoft YaHei', sans-serif";
    context.fillText(TASTE_LABELS[key], 135, y);
    context.fillStyle = "#e5e5de";
    context.beginPath();
    context.roundRect(270, y - 24, 570, 24, 12);
    context.fill();
    context.fillStyle = index % 2 ? "#b7d94b" : "#f25f32";
    context.beginPath();
    context.roundRect(270, y - 24, 570 * vector[key] / 100, 24, 12);
    context.fill();
    context.fillStyle = "#1e2923";
    context.font = "800 26px Arial, sans-serif";
    context.fillText(String(vector[key]), 875, y);
  });
  context.fillStyle = "#6e756f";
  context.font = "500 24px 'Microsoft YaHei', sans-serif";
  context.fillText("只有 8.7% 的食客和我一样", 135, 1060);
  context.fillStyle = "#fffdf8";
  context.font = "800 34px 'Microsoft YaHei', sans-serif";
  context.fillText("越吃，越懂你。", 80, 1245);
  context.fillStyle = "#bfc6c0";
  context.font = "500 22px Arial, sans-serif";
  context.fillText("JIANFENG TASTE GRAPH", 80, 1290);
  canvas.toBlob((blob) => {
    if (!blob) return;
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = `jianfeng-taste-${Date.now()}.png`;
    anchor.click();
    URL.revokeObjectURL(url);
  }, "image/png");
}

function FriendMatchSheet({ vector, onClose, recommendations }: { vector: TasteVector; onClose: () => void; recommendations: ReturnType<typeof recommendProducts> }) {
  const score = calculateTasteCompatibility(vector, DEMO_FRIEND_VECTOR);
  const common = TASTE_KEYS.map((key) => ({ key, score: Math.min(vector[key], DEMO_FRIEND_VECTOR[key]) })).sort((a, b) => b.score - a.score).slice(0, 3);
  const different = [...TASTE_KEYS].sort((a, b) => Math.abs(vector[b] - DEMO_FRIEND_VECTOR[b]) - Math.abs(vector[a] - DEMO_FRIEND_VECTOR[a]))[0];
  return (
    <div className="sheet-backdrop" onClick={onClose}>
      <article className="friend-sheet" onClick={(e) => e.stopPropagation()}>
        <button className="sheet-close" onClick={onClose} aria-label="关闭"><X size={20} /></button>
        <span className="eyebrow">FRIEND TASTE MATCH · DEMO</span>
        <div className="friend-sheet__faces"><i>J</i><span><Heart size={19} fill="currentColor" /></span><i>M</i></div>
        <h2>你们很会吃到一起</h2>
        <div className="big-match"><strong>{score}</strong><span>%</span><small>口味匹配度</small></div>
        <p>适合一起认真吃顿饭，也很可能为最后一块烤肉打起来。</p>
        <div className="common-taste">
          <span>共同喜欢</span>
          {common.map(({ key, score: value }) => <div key={key}><b>{TASTE_LABELS[key]}</b><i><em style={{ width: `${value}%` }} /></i><strong>{value}</strong></div>)}
        </div>
        <div className="difference"><span>最大分歧</span><strong>{TASTE_LABELS[different]}</strong><small>你 {vector[different]} · TA {DEMO_FRIEND_VECTOR[different]}</small></div>
        <div className="together-menu">
          <span>一起吃最合适</span>
          <div>{recommendations.slice(0, 3).map((item) => (
            <div key={item.product.id}>
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={item.product.image} alt="" /><small>{item.product.name}</small>
            </div>
          ))}</div>
        </div>
        <button className="primary-button" onClick={onClose}>生成邀请链接 <Share2 size={18} /></button>
      </article>
    </div>
  );
}

export function TasteApp() {
  const [view, setView] = useState<AppView>("welcome");
  const [questionIndex, setQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [selected, setSelected] = useState<number | null>(null);
  const [stored, setStored] = useState<StoredTaste>(DEFAULT_STORED);
  const [hydrated, setHydrated] = useState(false);
  const [feedIndex, setFeedIndex] = useState(0);
  const [dragX, setDragX] = useState(0);
  const [detail, setDetail] = useState<Product | null>(null);
  const [friendOpen, setFriendOpen] = useState(false);
  const [couponOpen, setCouponOpen] = useState(false);
  const [retestOpen, setRetestOpen] = useState(false);
  const [shareOpen, setShareOpen] = useState(false);
  const [methodOpen, setMethodOpen] = useState(false);
  const [toast, setToast] = useState("");
  const dragStart = useRef<number | null>(null);

  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved) as StoredTaste;
        setStored(parsed);
        if (parsed.answerCount >= QUESTIONS.length) setView("home");
      } catch { /* keep the clean prototype state */ }
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (hydrated) localStorage.setItem(STORAGE_KEY, JSON.stringify(stored));
  }, [stored, hydrated]);

  const liveDeltas = answers.map((answer, index) => QUESTIONS[index].options[answer].delta);
  const liveVector = useMemo(() => applyTasteTestAnswers(liveDeltas), [answers]);
  const recommendations = useMemo(() => recommendProducts(PRODUCTS, stored.vector), [stored.vector]);
  const confidence = calculateTasteConfidence(stored.answerCount, stored.swipeCount, stored.testConfidence);
  const currentFeed = recommendations[feedIndex % recommendations.length];

  const showToast = (message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(""), 2200);
  };

  const startTest = () => {
    setQuestionIndex(0);
    setAnswers([]);
    setSelected(null);
    setView("test");
  };

  const chooseAnswer = (optionIndex: number) => {
    if (selected !== null) return;
    setSelected(optionIndex);
    const nextAnswers = [...answers, optionIndex];
    window.setTimeout(() => {
      setAnswers(nextAnswers);
      setSelected(null);
      if (questionIndex === QUESTIONS.length - 1) {
        const score = scoreTasteTest(nextAnswers.map((answer, index) => QUESTIONS[index].options[answer].delta));
        setStored({ vector: score.vector, answerCount: QUESTIONS.length, swipeCount: 0, testConfidence: score.confidence, couponClaimed: stored.couponClaimed });
        setView("result");
      } else {
        setQuestionIndex((value) => value + 1);
      }
    }, 360);
  };

  const swipeAction = (weight: number) => {
    const signal = currentFeed.reasons.slice(0, 2).join("、");
    const label = weight < 0 ? `已略过，${signal}推荐会减少` : weight > 1 ? `已记住：${signal}信号增强` : `已加入想吃，正在学习${signal}`;
    setStored((current) => ({
      ...current,
      vector: updateTasteFromAction(current.vector, currentFeed.product.vector, weight),
      swipeCount: current.swipeCount + 1,
    }));
    setDragX(weight < 0 ? -520 : 520);
    window.setTimeout(() => {
      setFeedIndex((value) => (value + 1) % recommendations.length);
      setDragX(0);
      showToast(label);
    }, 240);
  };

  const onDragStart = (event: React.PointerEvent) => {
    dragStart.current = event.clientX;
    event.currentTarget.setPointerCapture(event.pointerId);
  };
  const onDragMove = (event: React.PointerEvent) => {
    if (dragStart.current !== null) setDragX(event.clientX - dragStart.current);
  };
  const onDragEnd = (event: React.PointerEvent) => {
    if (dragStart.current === null) return;
    try { event.currentTarget.releasePointerCapture(event.pointerId); } catch { /* already released */ }
    dragStart.current = null;
    if (Math.abs(dragX) > 85) swipeAction(dragX > 0 ? 1 : -1);
    else setDragX(0);
  };

  const changeNav = (next: NavView) => setView(next);
  const copyShare = async () => {
    try {
      await navigator.clipboard.writeText(`${window.location.origin}/?taste=JF0821`);
      showToast("Taste 链接已复制，发给那个懂吃的人吧");
    } catch {
      showToast("Taste Card 已准备好");
    }
  };
  const buy = () => {
    if (detail) window.open(detail.externalUrl, "_blank", "noopener,noreferrer");
    showToast("正在前往尖锋有赞商品页");
  };
  if (!hydrated) return <div className="app-shell"><div className="loading-mark"><Logo /><span /></div></div>;

  const activeNav = (["home", "discover", "taste", "profile"].includes(view) ? view : "home") as NavView;

  return (
    <div className="app-shell">
      <aside className="desktop-note">
        <span className="desktop-note__kicker">INTERACTIVE ENTRY · 2026</span>
        <strong>越吃，<br />越懂你。</strong>
        <p>把食品推荐从“猜你喜欢”，变成一张会随每次选择生长的个人 Taste Graph。</p>
        <div className="desktop-note__facts"><span><b>10</b> 维味觉信号</span><span><b>8</b> 个真实尖锋 SKU</span><span><b>0</b> 登录门槛</span></div>
        <div className="desktop-note__flow"><i>测</i><em /><i>懂</i><em /><i>吃</i><em /><i>更懂</i></div>
        <small>请在右侧手机中完成测试，或直接体验推荐、Swipe 与好友匹配。</small>
      </aside>
      <div className="phone-canvas">
        {view === "welcome" && <WelcomeView onStart={startTest} onExplain={() => setMethodOpen(true)} />}
        {view === "test" && <TasteTestView questionIndex={questionIndex} selected={selected} vector={liveVector} onSelect={chooseAnswer} onBack={() => questionIndex === 0 ? setView("welcome") : (setQuestionIndex((v) => v - 1), setAnswers((v) => v.slice(0, -1)))} />}
        {view === "result" && <ResultView vector={stored.vector} confidence={confidence} onContinue={() => stored.couponClaimed ? setView("home") : setCouponOpen(true)} onShare={() => setShareOpen(true)} />}
        {view === "home" && <HomeView vector={stored.vector} confidence={confidence} recommendations={recommendations} onProduct={setDetail} onDiscover={() => setView("discover")} onTaste={() => setView("taste")} couponClaimed={stored.couponClaimed} />}
        {view === "discover" && currentFeed && <DiscoverView item={currentFeed} index={feedIndex} total={recommendations.length} dragX={dragX} onDragStart={onDragStart} onDragMove={onDragMove} onDragEnd={onDragEnd} onAction={swipeAction} onProduct={setDetail} />}
        {view === "taste" && <TasteProfileView vector={stored.vector} confidence={confidence} swipeCount={stored.swipeCount} onShare={() => setShareOpen(true)} onFriend={() => setFriendOpen(true)} onRetest={() => setRetestOpen(true)} />}
        {view === "profile" && <ProfileView swipeCount={stored.swipeCount} onReset={() => setRetestOpen(true)} onFeedback={showToast} />}
        {(["home", "discover", "taste", "profile"] as AppView[]).includes(view) && <BottomNav active={activeNav} onChange={changeNav} />}
        {detail && <ProductSheet product={detail} vector={stored.vector} couponClaimed={stored.couponClaimed} onClose={() => setDetail(null)} onBuy={buy} />}
        {friendOpen && <FriendMatchSheet vector={stored.vector} onClose={() => setFriendOpen(false)} recommendations={recommendProducts(PRODUCTS, Object.fromEntries(TASTE_KEYS.map((key) => [key, (stored.vector[key] + DEMO_FRIEND_VECTOR[key]) / 2])) as TasteVector)} />}
        {couponOpen && <CouponSheet onClaim={() => { setStored((current) => ({ ...current, couponClaimed: true })); setCouponOpen(false); setView("home"); showToast("¥10 Taste 券已放进“我的”"); }} onSkip={() => { setCouponOpen(false); setView("home"); }} />}
        {retestOpen && <RetestSheet couponClaimed={stored.couponClaimed} onClose={() => setRetestOpen(false)} onConfirm={() => { setRetestOpen(false); startTest(); }} />}
        {shareOpen && <ShareCardSheet vector={stored.vector} onClose={() => setShareOpen(false)} onCopy={copyShare} onSave={() => { saveTasteCardPng(stored.vector); showToast("Taste Card 已生成并开始下载"); }} />}
        {methodOpen && <MethodSheet onClose={() => setMethodOpen(false)} />}
        {toast && <div className="toast"><Check size={16} /> {toast}</div>}
      </div>
    </div>
  );
}
